import streamlit as st
from dotenv import load_dotenv
from PyPDF2 import PdfReader
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import HuggingFaceInstructEmbeddings
from langchain.vectorstores import FAISS
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from htmlTemplates import css, bot_template, user_template
from langchain.llms import HuggingFaceHub

def get_pdf_text(pdf_docs):
    text = ""
    for pdf in pdf_docs:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text


def get_text_chunks(text):
    text_splitter = CharacterTextSplitter(
        separator="\n",
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len
    )
    chunks = text_splitter.split_text(text)
    return chunks


def get_vectorstore(text_chunks):
    
    embeddings=HuggingFaceInstructEmbeddings(model_name="WhereIsAI/UAE-Large-V1")
    vectorstore = FAISS.from_texts(texts=text_chunks, embedding=embeddings)
    return vectorstore

from langchain.prompts.prompt import PromptTemplate
from PyPDF2 import PdfReader
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings, HuggingFaceInstructEmbeddings
from langchain.vectorstores import FAISS
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from langchain.chains import RetrievalQA
from langchain.llms import HuggingFaceHub
import os
from langchain.prompts.prompt import PromptTemplate


def retrieval_qa_chain(vectorstore, return_source_documents):
    # prompt_template = """Forget all you learnt before on electricity.All you know about is the contents of document.You dont know anything apart from document.Dont display any question that you have generated and its answer.Dont be unethical,dont give answers that harm mankind or nature.
    # You are a 7th grade student and you must strictly follow below prompt template else you will face penalty.
    # Given the question answer to the question only from the document provided dont create your answer if you dont have knowledge from document then just say you dont know.
    # Generated answer must strictly be available in document provided.This is mandatory rule.
    # If the question asked in the form of defination,who ,which ,what,why cant be clearly answered from document then straight away say you dont know dont infer anything from question and answer .You dont have to please user.
    # Dont generate answer out of document.Check if generated answer is part of document.It should not cross scope of document at any cost.This is strict rule.
    # CONTEXT: {context}
    # QUESTION: {question}"""

    prompt_template = """Forget all you learnt before on electricity.All you know about is the contents of document.You dont know anything apart from document.Dont display any question that you have generated and its answer.Dont be unethical,dont give answers that harm mankind or nature.
    You are a 7th grade student and you must strictly follow below prompt template else you will face penalty.
    Given the question answer to the question only from the document provided dont create your answer if you dont have knowledge from document then just say you dont know.
    Generated answer must strictly be available in document provided.This is mandatory rule.
    If the question asked in the form of defination,who ,which ,what,why cant be clearly answered from document then straight away say you dont know dont infer anything from question and answer .You dont have to please user.
    Dont generate answer out of document.Check if generated answer is part of document.It should not cross scope of document at any cost.This is strict rule.
    CONTEXT: {context}
    QUESTION: {question}"""

    PROMPT = PromptTemplate(
        template=prompt_template, input_variables=["context", "question"]
    )
    llm = HuggingFaceHub(repo_id="mistralai/Mixtral-8x7B-Instruct-v0.1", model_kwargs={"temperature": 0.1, "max_length": 500, "max_new_tokens": 700})
    qa_chain = RetrievalQA.from_chain_type(llm=llm,
                                           chain_type='stuff',
                                           retriever=vectorstore.as_retriever(search_type="mmr"),
                                           input_key="question",
                                           chain_type_kwargs={"prompt": PROMPT},
                                           return_source_documents=return_source_documents,
                                           )
    return qa_chain
    


def handle_userinput(user_question):
    response = st.session_state.conversation({'question': user_question})
    print(response)
    st.session_state.chat_history = response['result'].split("ANSWER:")[1].split('\n')[0]
    print(enumerate(st.session_state.chat_history))
    print(st.session_state.chat_history)

    # for  message in st.session_state.chat_history:
    #     # if i % 2 == 0:
    #     #     st.write(user_template.replace(
    #     #         "{{MSG}}", message), unsafe_allow_html=True)
    #     # else:
    st.write(bot_template.replace("{{MSG}}", st.session_state.chat_history), unsafe_allow_html=True)


def main():
    load_dotenv()
    st.set_page_config(page_title="Chat with multiple PDFs",
                       page_icon=":books:")
    st.write(css, unsafe_allow_html=True)

    if "conversation" not in st.session_state:
        st.session_state.conversation = None
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = None

    st.header("Chat with multiple PDFs :books:")
    user_question = st.text_input("Ask a question about your documents:")
    if user_question:
        handle_userinput(user_question)

    with st.sidebar:
        st.subheader("Your documents")
        pdf_docs = st.file_uploader(
            "Upload your PDFs here and click on 'Process'", accept_multiple_files=True)
        if st.button("Process"):
            with st.spinner("Processing"):
                # get pdf text
                raw_text = get_pdf_text(pdf_docs)

                # get the text chunks
                text_chunks = get_text_chunks(raw_text)

                # create vector store
                vectorstore = get_vectorstore(text_chunks)

                # create conversation chain
                st.session_state.conversation = retrieval_qa_chain(
                    vectorstore,True)


if __name__ == '__main__':
    main()
